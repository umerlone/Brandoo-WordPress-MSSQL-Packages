                                                                                                               
 :::::::,.``                                                                                                   
 ::::::::::::::::,,.                                                                                           
 :::::::::::::::::::                                                                                           
 :::::::::::::::::::                                                                                           
 :::::.  :::::::::::`                                                      ++.                                 
 :::::.  :::::::::::,                                                      ##.                                 
 ,::::.  ::::::::::::                                                      ##.                                 
 .::::.  ::::::::::::                                                      ##.                                 
 `::::.  :,`   `,::::       +####.   ######`    '########.          '###'  ##.      `####.           +###;     
 `::::.  `       `:::     ,######`   +######:   '##########       '#######'##.     ########`       +#######;   
  ::::.            ::`    #######.   ########   '###########     ############.    ##########`     ##########'  
  ::::.    ,:::,   .:.   +##:             ,##,  '##      ###    :###`   .####.   ###+    +###    '###    ,###` 
  ::::.   :::::::   :,   ###               ##;  '##       ##,   ###       ###.  ,###      '##'   ###      `### 
  ::::.  `:::::::   ::   ##+               ##;  '##       ##;   ##;       '##.  ###        ###  .##:       ### 
  ,:::.  :::::::::  .:   ##+      :##########;  '##       ##;  ;##        `##.  ###        +##  ;##        `##`
  ,:::.  :::::::::  .:   ##+     :###########;  '##       ##;  ;##         ##.  ###        +##  ;##        `##.
  .:::,  .:::::::`  ::   ##+     ###;,,,,,,##;  '##       ##;  .##,       ;##`  ###        ###  ,##.       '## 
  `::::   :::::::   ::`  ##+     ##'       ##;  '##       ##;   ###       ###   ;##;      ,##+   ###       ### 
   ::::`   :::::   `::,  ##+     ##'      `##:  '##       ##;   +###     ###'    ###:    ,###    +##+     ###: 
   :::::           ::::  ##+     ############`  '##       ##;    ###########     .##########:     ###########  
   ::::::         :::::  ##+     ,##########+   '##       ##;     #########       ,########;       #########   
   :::::::.     .::::::  ##+      .########;    '##       ##;      ,#####.          '####+          :#####.    
   ::::::::::::::::::::                                                                                        
   ::::::::::::::::::::`                                                                                       
   ,::::::::::::::::::.                                                                                        
   `:::::::::::::::`                                                                                           
    :::::::::::,                                                                                               
    ::::::::`                                                                                                  
    ::::,                                                                                                      
    :.                                                                                                         
                                                                                                               
                                                                                                               
                                                                                                               
We are the humans behind Brandoo WordPress for MSSQL and MS Azure SQL

/* TEAM */
Name: Paweł Czyżewski
Title: Main Developer
e-mail: pawel.czyzewski@brandoo.pl

Name: Michał Smereczyński
Title: Project Lead
Twitter: smereczynski
e-mail: michal.smereczynski@brandoo.pl

/* THANKS */
OmniTI team (http://omniti.com/), T4ngram

/* DESCRIPTION */
Brandoo WordPress (MS SQL or Azure SQL) includes latest, stable version of WordPress CMS, Database Abstraction plugin
created by OmniTI team to make possible to run a WordPress CMS using MS SQL Server or Azure SQL.
Brandoo WordPress (MS SQL or Azure SQL) also includes WordPress installer, improved by Brandoo team,
that helps to automate the installation process.

Database Abstraction plugin included in package provides two features: database access abstraction
and SQL dialect abstraction.

Database Access Abstraction is the way you connect to the database through PHP.

SQL dialect abstraction means translating from the dialect understood by Mysql
to other dialects.  Currently only translation layers for T-SQL (used by Azure and SQL Server)
are provided.

Improved installer helps to automate the installation process in Microsoft Web Platform Installer, Microsoft WebMatrix
and Windows Azure Public/Private cloud.

Microsoft Web Platform Installer , Microsoft Web Matrix and Windows Azure Public/Private cloud installer files
are located in GitHub repositorry: https://github.com/Brandoo/Brandoo-WordPress-WWAG-installator

Complete packages for Windows Web App Gallery are located in GitHub repository:
https://github.com/Brandoo/Brandoo-WordPress-MSSQL-Packages

Bundle was created with Windows Web Application Gallery in mind.

/* META */
Updated: 2013/06/13
See: http://brandoo.pl


