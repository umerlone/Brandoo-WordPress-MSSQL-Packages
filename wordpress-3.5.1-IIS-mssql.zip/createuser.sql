/**********************************************************************/
/* CreateUser.SQL */
/* Creates a user and makes the user a member of db roles */
/* This script runs against the User database and requires connection string */
/* Supports SQL Server and SQL AZURE */
/**********************************************************************/
USE PlaceholderForDbName ;

-- Create database user and map to login
-- and add user to the datareader, datawriter, ddladmin and securityadmin roles
--

CREATE USER PlaceholderForDbUsername FOR LOGIN PlaceholderForDbUsername;
GO
EXEC sp_addrolemember 'db_ddladmin', PlaceholderForDbUsername;
EXEC sp_addrolemember 'db_securityadmin', PlaceholderForDbUsername;
EXEC sp_addrolemember 'db_datareader', PlaceholderForDbUsername;
EXEC sp_addrolemember 'db_datawriter', PlaceholderForDbUsername;
GO
